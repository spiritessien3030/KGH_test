import 'package:flutter/material.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Orders")),
      body: ListView(
        children: const [
          ListTile(title: Text("Order #1001"), subtitle: Text("Pending")),
          ListTile(title: Text("Order #1002"), subtitle: Text("Completed")),
        ],
      ),
    );
  }
}