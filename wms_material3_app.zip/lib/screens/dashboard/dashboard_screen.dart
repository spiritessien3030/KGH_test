import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dashboard")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: const [
                Expanded(child: _Card(title: "Total Stock", value: "1200")),
                SizedBox(width: 10),
                Expanded(child: _Card(title: "Low Stock", value: "15")),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: const [
                Expanded(child: _Card(title: "Orders", value: "32")),
                SizedBox(width: 10),
                Expanded(child: _Card(title: "Pending", value: "8")),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title;
  final String value;

  const _Card({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(title),
            const SizedBox(height: 8),
            Text(value, style: Theme.of(context).textTheme.headlineMedium),
          ],
        ),
      ),
    );
  }
}